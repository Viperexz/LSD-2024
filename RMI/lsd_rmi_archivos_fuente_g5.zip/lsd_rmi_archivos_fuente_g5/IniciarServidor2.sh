# shellcheck disable=SC2164
cd bin/
java grsaa.ServidorDeObjetos2
