# shellcheck disable=SC2164
cd bin/
java plc_mms.ServidorDeObjetos